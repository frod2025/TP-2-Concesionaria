package ar.org.centro8.java.curso.concesionaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoConcecionariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
