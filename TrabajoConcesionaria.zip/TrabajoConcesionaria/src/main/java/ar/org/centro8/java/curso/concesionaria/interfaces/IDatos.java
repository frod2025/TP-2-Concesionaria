package ar.org.centro8.java.curso.concesionaria.interfaces;

public interface IDatos {
    // Interface con la firma a utilizar en las clases Auto y Moto
    String verDatos();
}
