package ar.org.centro8.java.curso.concesionaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoConcesionariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoConcesionariaApplication.class, args);
	}
}
