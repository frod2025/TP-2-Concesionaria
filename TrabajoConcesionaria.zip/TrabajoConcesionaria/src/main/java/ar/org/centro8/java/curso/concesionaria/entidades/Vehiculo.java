package ar.org.centro8.java.curso.concesionaria.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;

    @Override
    public int compareTo(Vehiculo oVehiculo) {
        // Comparo marca (alfabéticamente)
        int compMarca = this.marca.compareTo(oVehiculo.marca);
        if (compMarca != 0)
            return compMarca;

        // Si la marca es igual, comparo modelo
        int compModelo = this.modelo.compareTo(oVehiculo.modelo);
        if (compModelo != 0)
            return compModelo;

        // Si marca y modelo son iguales, comparo por precio numérico
        return Double.compare(this.precio, oVehiculo.precio);
    }

}
