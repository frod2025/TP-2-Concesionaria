package ar.org.centro8.java.curso.concesionaria.tests;

import ar.org.centro8.java.curso.concesionaria.entidades.Auto;
import ar.org.centro8.java.curso.concesionaria.entidades.ListaVehiculo;
import ar.org.centro8.java.curso.concesionaria.entidades.Moto;
import ar.org.centro8.java.curso.concesionaria.entidades.Vehiculo;
import ar.org.centro8.java.curso.concesionaria.interfaces.IDatos;

public class TestConcesionaria {
        public static void main(String[] args) {

                ListaVehiculo lista = new ListaVehiculo();
                lista.agregarVehiculos(
                                new Auto("Peugeot", "206", 200000, 4),
                                new Moto("Honda", "Titan", 60000, 125),
                                new Auto("Peugeot", "208", 250000, 5),
                                new Moto("Yamaha", "YBR", 80500.50, 160));

                lista.mostrarTodos();

                System.out.println("\n=============================\n");

                Vehiculo masCaro = lista.getMasCaro();
                Vehiculo masBarato = lista.getMasBarato();

                System.out.println("Vehículo más caro: " + masCaro.getMarca() + " " + masCaro.getModelo());
                System.out.println("Vehículo más barato: " + masBarato.getMarca() + " " + masBarato.getModelo());

                Vehiculo contieneY = lista.getContieneY();
                if (contieneY != null) {
                        System.out.printf("Vehículo que contiene en el modelo la letra 'Y': %s %s $%,.2f%n",
                                        contieneY.getMarca(), contieneY.getModelo(), contieneY.getPrecio());
                }

                System.out.println("\n=============================\n");

                System.out.println("Vehículos ordenados por precio de mayor a menor:");
                lista.getOrdenadosPorPrecioDesc()
                                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));

                System.out.println("\n=============================\n");

                System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
                lista.getOrdenNatural()
                                .forEach(v -> System.out.println(((IDatos) v).verDatos()));
        }

}
