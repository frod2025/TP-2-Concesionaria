package ar.org.centro8.java.curso.concesionaria.entidades;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.centro8.java.curso.concesionaria.interfaces.IDatos;

public class ListaVehiculo {

    private List<Vehiculo> vehiculos = new ArrayList<>();

    /**
     * Metodo para agregar vehiculos a la lista con varargs
     * 
     * @param v
     */
    public void agregarVehiculos(Vehiculo... v) {
        for (int i = 0; i < v.length; i++) {
            vehiculos.add(v[i]);
        }
    }

    public Vehiculo getMasCaro() {
        return vehiculos.stream()
                .max(Comparator.comparing(Vehiculo::getPrecio))
                .orElse(null);
    }

    public Vehiculo getMasBarato() {
        return vehiculos.stream()
                .min(Comparator.comparing(Vehiculo::getPrecio))
                .orElse(null);
    }

    /**
     * Devuelve el primer vehículo cuyo modelo contiene la letra 'Y'
     */
    public Vehiculo getContieneY() {
        return vehiculos.stream()
                .filter(v -> v.getModelo().toUpperCase().contains("Y"))
                .findFirst()
                .orElse(null);
    }

    public List<Vehiculo> getOrdenadosPorPrecioDesc() {
        return vehiculos.stream()
                .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
                .collect(Collectors.toList());
    }

    public List<Vehiculo> getOrdenNatural() {
        return vehiculos.stream()
                .sorted() // usa compareTo() de Vehiculo
                .collect(Collectors.toList());
    }

    public List<Vehiculo> getContieneLetra(String letra) {
        return vehiculos.stream()
                .filter(v -> v.getModelo().toUpperCase().contains(letra.toUpperCase()))
                .collect(Collectors.toList());
    }

     /**
     * Devuelve todos los vehiculos
     */
    public void mostrarTodos() {
        vehiculos.forEach(v -> System.out.println(((IDatos) v).verDatos()));
    }

}
