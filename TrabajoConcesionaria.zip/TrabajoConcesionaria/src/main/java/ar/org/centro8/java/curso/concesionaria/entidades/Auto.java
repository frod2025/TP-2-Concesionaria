package ar.org.centro8.java.curso.concesionaria.entidades;

import java.text.DecimalFormat;

import ar.org.centro8.java.curso.concesionaria.interfaces.IDatos;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class Auto extends Vehiculo implements IDatos {
    private int cantidadPuertas;

    public Auto(String marca, String modelo, double precio, int cantidadPuertas) {
        super(marca, modelo, precio);
        this.cantidadPuertas = cantidadPuertas;
    }

    @Override
    public String verDatos() {
        DecimalFormat df = new DecimalFormat("$#,##0.00");
        return String.format("Marca: %s // Modelo: %s // Puertas: %d // Precio: %s",
                getMarca(), getModelo(), getCantidadPuertas(), df.format(getPrecio()));
    }
}
