package ar.org.centro8.java.curso.concesionaria.entidades;

import java.text.DecimalFormat;

import ar.org.centro8.java.curso.concesionaria.interfaces.IDatos;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class Moto extends Vehiculo implements IDatos {
    private int cilindrada;

    public Moto(String marca, String modelo, double precio, int cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }
    @Override
    public String verDatos() {
        DecimalFormat df = new DecimalFormat("$#,##0.00");
        return String.format("Marca: %s // Modelo: %s // Cilindrada: %dc // Precio: %s",
                getMarca(), getModelo(), getCilindrada(), df.format(getPrecio()));
    }
}
